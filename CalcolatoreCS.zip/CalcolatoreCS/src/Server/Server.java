package Server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    ServerSocket server;
    Socket msocket;
    BufferedReader in;
    DataOutputStream out;
    public Socket attendi() {
        try {
            System.out.println("Server avviato...");
            server = new ServerSocket(8080);

            msocket = server.accept();
            System.out.println("Connessione riuscita col client ");

            server.close();

            out = new DataOutputStream(msocket.getOutputStream());
            in = new BufferedReader(new InputStreamReader(msocket.getInputStream()));

        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante la funzione del server");
            System.exit(1);
        }
        return msocket;
    }


    public void calcola(){
        try{
            double x;
            double y;
            double risultato=0;
           
            int scelta = in.read();

            x = in.read();

            System.out.println("x "+x);
            y = in.read();
            System.out.println("y "+y);

            switch (scelta){
                case 1:
                    System.out.println("Scelta: "+scelta);

                    risultato = x+y;
		
		 case 2:
                    System.out.println("Scelta: "+scelta);

                    risultato = x-y;

		 case 3:
                    System.out.println("Scelta: "+scelta);

                    risultato = x*y;

		 case 4:
                    System.out.println("Scelta: "+scelta);

                    risultato = x/y;


            }
            System.out.println("Risultato: "+risultato);

        }catch (Exception e){

        }
    }


    public static void main(String args[]) {
        Server myServer = new Server();
        myServer.attendi();
        myServer.calcola();
    }
}
