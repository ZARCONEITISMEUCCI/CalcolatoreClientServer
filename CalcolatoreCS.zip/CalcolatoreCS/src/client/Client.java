package client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client{
    Socket socket;
    protected int porta = 8080;
    String nomeServer = "localhost";
    DataOutputStream out;
    DataInputStream in;


    Scanner input = new Scanner(System.in);

    public Socket connetti(){
        try {
            System.out.println("Client avviato...");
            
            socket = new Socket(nomeServer, porta);
            System.out.println("Client connesso a ' "+nomeServer+" ' sulla porta: "+porta);
          
            out = new DataOutputStream(socket.getOutputStream());
            in = new DataInputStream(socket.getInputStream());

        } catch (Exception e){
            System.out.println("Errore, connessione non riuscita");
            System.exit(1);
        }
        return socket;

    }

    private void menu(){
        try{
            System.out.println("Calcolatore Client/Server");
            System.out.println("[1.Somma \t 2.Differenza \t 3.Moltiplicazione \t 4.Divisione]");
            System.out.println("0.ESCI");
        } catch (Exception e){
            System.out.println("Errore");
        }


    }

 
    public void comunica(){
        try {
            int scelta=0;
       
                menu();
                System.out.println("Inserire operazione ");
                scelta = input.nextInt();
   

                out.write(scelta);

                System.out.println("Scrivi il primo numero.");
                double x = input.nextDouble();
                out.writeDouble(x);

                System.out.println("Scrivi il secondo numero.");
                double y = input.nextDouble();
                out.writeDouble(y);

        }catch (IOException e){

        }


    }
}
